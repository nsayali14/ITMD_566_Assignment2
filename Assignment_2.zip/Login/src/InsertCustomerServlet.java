

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.xml.internal.ws.developer.MemberSubmissionAddressing.Validation;

import customerservlet.Validator;
import customerservlet.ValidatorFactory;

/**
 * Servlet implementation class InsertCustomerServlet
 */
@WebServlet("/InsertCustomerServlet")
public class InsertCustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Bean customer = new Bean();
	ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
	Validator validator = factory.getValidator(); 
    /**
     * @see HttpServlet#HttpServlet()
     */
	
	@NotNull(message = "Customer Name is required")
	 @Size(min = 4, max = 50, message = "Customer Name should not exceed the limit 4-50")
	    private String name;
	 
	  @NotNull(message="Social Security is required")
	  @Size(min=11,max=11,message="SSN should be of 11 characters")
	  private String ssn;
	  
	    @NotNull(message="ZipCode is required")
	    @Pattern(regexp="(^\\d{5}$)|(^\\d{5}-\\d{4}$)",message="Zip Code must be valid")
	    private int zipcode;
	    
	    @NotNull(message = "Address is required")
		 @Size(min = 4, max = 50, message = "Address should not exceed the limit 4-50")
		    private String address;
	    
	    @NotNull(message = "City is required")
		 @Size(min = 3, max = 50, message = "City mshould not exceed the limit 3-50")
		    private String City;
	    
	    @NotNull(message = "Email is required")
	    @Pattern(regexp="^(([^<>()\\[\\]\\\\.,;:\\s@\"]+(\\.[^<>()\\[\\]\\\\.,;:\\s@\"]+)*)|(\".+\"))@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$", message="Email should be valid")
	    
	    private String email;
	    public InsertCustomerServlet() {
       super();
   
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try
		{	    

		     Bean user = new Bean();
		     user.setName(request.getParameter("un"));
		     user.setssn(request.getParameter("pw"));

		     user = UserDAO.login(user);
			   		    
		     if (user.isValid())
		     {
			        
		          HttpSession session = request.getSession(true);	    
		          session.setAttribute("currentSessionUser",user); 
		          response.sendRedirect("userLogged.jsp"); //logged-in page      		
		     }
			        
		     else 
		          response.sendRedirect("invalidLogin.jsp"); //error page 
		} 
				
				
		catch (Throwable theException) 	    
		{
		     System.out.println(theException); 
		}
		       }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("----- InsertCustomerServlet -----");
        try {
        // Get the customer value 
            String name=request.getParameter("name");
            String ssn=request.getParameter("ssn");
            String zipcode=request.getParameter("zipcode");
            String emailid=request.getParameter("emailid");
            String address=request.getParameter("address");
            String mobile=request.getParameter("city");
            String state=request.getParameter("state");
             
            //Set the Customer values
            Bean customer=new Bean();
            customer.setName(name);
            customer.setssn(ssn);
            customer.setzipcode(zipcode);
            customer.setEmailid(emailid);
            customer.setaddress(address);
            customer.setcity(City);
            customer.setstate(state);
       
             
            RequestDispatcher dispatcher=request.getRequestDispatcher("/ProcessCustomerDataRequest.jsp");
           
            request.setAttribute("cust",customer);
            dispatcher.forward(request, response);
        } catch (ServletException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }catch(Exception e){
            e.printStackTrace();
        }
         
    }
 
	}


